//
//  UITextView+Create.m
//  CommomTool
//
//  Created by Apple on 2020/9/11.
//  Copyright © 2020 Apple. All rights reserved.
//

#import "UITextView+Create.h"

@implementation UITextView (Create)
+ (instancetype)textViewWithFrame:(CGRect)frame font:(UIFont *)font textColor:(UIColor *)textColor text:(NSString *)text backgroundColor:(UIColor *)backgroundColor parentView:(UIView *)parentView {
    UITextView *textView = [[UITextView alloc] initWithFrame:frame];
    if (font) {
        textView.font = font;
    }
    if (textColor) {
        textView.textColor = textColor;
    }
    if (text) {
        textView.text = text;
    }
    if (backgroundColor) {
        textView.backgroundColor = backgroundColor;
    }
    
    if (parentView) {
        [parentView addSubview:textView];
    }
    return textView;
}
@end

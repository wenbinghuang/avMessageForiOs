//
//  UIView+Create.h
//  CommomTool
//
//  Created by Apple on 2020/9/11.
//  Copyright © 2020 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_OPTIONS(NSInteger, ShadowPathType) {
    ShadowPathTop = 0,
    ShadowPathBottom= 1,
    ShadowPathLeft = 2,
    ShadowPathRight = 3,
    ShadowPathCommon = 4,
    ShadowPathAround = 5,
};

@interface UIView (Create)
+ (instancetype)viewWithFrame:(CGRect)frame backgroundColor:(UIColor *__nullable)backgroundColor shouldRadius:(BOOL)shouldRadius radius:(CGFloat)radius shouldShadowOffset:(BOOL)shouldShadowOffset shadowOffset:(CGSize)shadowOffset shadowColor:(UIColor * __nullable)shadowCorlor shadowOpacity:(CGFloat)shadowOpacity shouldBorderWidth:(BOOL)shouldBorderWidth
        borderWidth:(CGFloat)borderWidth borderColor:(UIColor * __nullable)borderColor  parentView:(UIView * __nullable )parentView;
@end

NS_ASSUME_NONNULL_END

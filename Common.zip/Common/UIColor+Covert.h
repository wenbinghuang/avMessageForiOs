//
//  UIColor+Covert.h
//  CommomTool
//
//  Created by Apple on 2020/9/11.
//  Copyright © 2020 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
#define UIColorRGB(r,g,b) RGBA(r,g,b,1)
#define UIColorRGBA(r,g,b,a)  [UIColor colorWithR:(r) G:(g) B:(b) alpha:(a)]


@interface UIColor (Covert)
/**根据16进制生成颜色，不透明度默认为1*/
+ (instancetype)colorWithHexString:(NSString*)hexString;
/**根据16进制生成颜色，设置透明度*/
+ (instancetype)colorWithHexString:(NSString*)hexString alpha:(float)alpha;
/**RGB生成颜色*/
+ (instancetype)colorWithR:(float)R G:(float)G B:(float)B alpha:(float)alpha;
@end

NS_ASSUME_NONNULL_END

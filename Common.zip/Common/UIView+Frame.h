//
//  UIView+Frame.h
//  CommomTool
//
//  Created by Apple on 2020/9/15.
//  Copyright © 2020 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#define knormalPer [UIScreen mainScreen].bounds.size.width / 28.0
NS_ASSUME_NONNULL_BEGIN

@interface UIView (Frame)
@property(nonatomic,assign)CGFloat x;
@property(nonatomic, assign)CGFloat y;
@property(nonatomic, assign)CGFloat width;
@property(nonatomic,assign)CGFloat height;
@property(nonatomic,assign)CGFloat center_x;
@property(nonatomic, assign)CGFloat center_y;
/**边框线宽*/
@property(nonatomic,assign)CGFloat borderWidth;
/**半径弧度*/
@property(nonatomic,assign)CGFloat radius;
/**边框颜色*/
@property(nonatomic,strong)UIColor *borderColor;
@property(nonatomic, assign,readonly)CGFloat left;
@property(nonatomic, assign,readonly)CGFloat top;
@property(nonatomic, assign,readonly)CGFloat right;
@property(nonatomic, assign,readonly)CGFloat bottom;

@end

NS_ASSUME_NONNULL_END

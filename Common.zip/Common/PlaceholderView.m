//
//  PlaceholderView.m
//  IT资产移动助手运维端
//
//  Created by Apple on 2020/4/26.
//

#import "PlaceholderView.h"
#import "UIView+Frame.h"


@interface PlaceholderView ()<UITextViewDelegate>

@property(nonatomic, weak)UILabel *placeholderLabel;
@property(nonatomic, assign)CGFloat orinHeight;
@property(nonatomic, weak)UILabel *tipLabel;
@end

@implementation PlaceholderView

+ (instancetype)placeholderViewWithFrame:(CGRect)frame {
    PlaceholderView *placeView = [[PlaceholderView alloc] initWithFrame:frame];
    [placeView setupSubviews];
    return placeView;
}





- (void)setupSubviews {
    self.orinHeight = CGRectGetHeight(self.frame);
    UITextView *textView = [[UITextView alloc] initWithFrame:self.bounds];
    textView.textContainerInset = UIEdgeInsetsMake(CGRectGetHeight(textView.frame) * 0.25, 0, CGRectGetHeight(textView.frame) * 0.25, 0);
    [self addSubview:textView];
    textView.scrollEnabled = NO;
    textView.delegate = self;
    textView.inputAccessoryView = [self addToolbar];
    self.textView = textView;
    UILabel *placeholderLabel = [[UILabel alloc] initWithFrame:self.bounds];
    [self addSubview:placeholderLabel];
    placeholderLabel.textColor = [UIColor lightTextColor];
    self.placeholderLabel = placeholderLabel;
    CGFloat normal = [UIScreen mainScreen].bounds.size.width / 28.0;
    UILabel *tipLabel = [[UILabel alloc] initWithFrame:CGRectMake(normal, 0, 10 * normal, 1.5 * normal)];
    [self addSubview:tipLabel];
    tipLabel.textColor = [UIColor darkGrayColor];
    self.tipLabel = tipLabel;
    self.tipLabel.hidden = YES;
    self.tipLabel.textAlignment = NSTextAlignmentRight;
}


- (void)setFont:(UIFont *)font {
    _font = font;
    self.placeholderLabel.font = font;
    self.textView.font = font;
    self.tipLabel.font = font;
}


- (void)setPlaceholder:(NSString *)placeholder {
    _placeholder = placeholder;
    self.placeholderLabel.text = placeholder;
}


- (void)setPlaceholderColor:(UIColor *)placeholderColor {
    _placeholderColor = placeholderColor;
    self.placeholderLabel.textColor = placeholderColor;
}

- (void)setTextAlignment:(NSTextAlignment)textAlignment {
    _textAlignment = textAlignment;
    self.placeholderLabel.textAlignment = textAlignment;
    self.textView.textAlignment = textAlignment;
}

- (void)setContentEdge:(UIEdgeInsets)contentEdge {
    _contentEdge = contentEdge;
    self.textView.contentInset = contentEdge;
    
    self.placeholderLabel.frame = CGRectMake(contentEdge.left, CGRectGetMinX(self.placeholderLabel.frame), CGRectGetWidth(self.placeholderLabel.frame), CGRectGetHeight(self.placeholderLabel.frame));
}



- (void)setBackgroundColor:(UIColor *)backgroundColor {
    [super setBackgroundColor:backgroundColor];
    self.textView.backgroundColor = backgroundColor;
}


- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    
    if ([text isEqualToString:@"\n"]) {
        return NO;
    }
    if ([text isEqualToString:@" "]) {
        if ([self.placeholder containsString:@"备注"] || [self.placeholder containsString:@"机柜"] || [self.placeholder containsString:@"编码"]) {
            return YES;
        }
        return NO;
    }
//    if (self.maxLenth != 0) {
//        if ([text isEqualToString:@""]) {
//            return YES;
//        }
//        if (textView.text.length - range.length + text.length > self.maxLenth) {
//            return NO;
//        }
//    }
    
    
    return YES;
}


- (void)textViewDidChange:(UITextView *)textView {
    CGFloat fixedWidth = textView.frame.size.width;
    CGSize newSize = [textView sizeThatFits:CGSizeMake(fixedWidth, MAXFLOAT)];
   CGFloat normal = [UIScreen mainScreen].bounds.size.width / 28.0;
    CGRect newFrame = textView.frame;
    newFrame.size = CGSizeMake(fmaxf(newSize.width, fixedWidth), fmaxf(newSize.height,self.orinHeight));
    textView.frame = newFrame;
    self.frame = CGRectMake(self.x, self.y, self.width, textView.height);
    self.placeholderLabel.hidden = (textView.text.length > 0);
  
        if (self.delegate && [self.delegate respondsToSelector:@selector(textViewDidChangeFrame:placeView:)]) {
            [self.delegate textViewDidChangeFrame:self.frame placeView:self];
        }
    
    NSString *lang = [[UITextInputMode activeInputModes].firstObject primaryLanguage];
    if (self.maxLenth > 0) {
        if (self.text.length > 0) {
            self.tipLabel.hidden = NO;
        } else {
            self.tipLabel.hidden = YES;
        }
        
        self.frame = CGRectMake(CGRectGetMinX(self.frame), CGRectGetMinY(self.frame), CGRectGetWidth(self.frame), CGRectGetHeight(textView.frame) + CGRectGetHeight(self.tipLabel.frame));
        self.tipLabel.frame = CGRectMake(CGRectGetWidth(self.frame) - CGRectGetWidth(self.tipLabel.frame) - 0.5 * normal, CGRectGetMaxY(textView.frame), CGRectGetWidth(self.tipLabel.frame), CGRectGetHeight(self.tipLabel.frame));
        NSInteger leftLenth = self.maxLenth - textView.text.length;
        if (leftLenth < 0) {
            leftLenth = 0;
        }
        NSString *tipStr = [NSString stringWithFormat:@"还可输入%zd个字",leftLenth];
        if ([lang isEqualToString:@"zh-Hans"]) {
            UITextRange *range = [textView markedTextRange];
            UITextPosition *start = range.start;
            UITextPosition*end = range.end;
            NSInteger selectLength = [textView offsetFromPosition:start toPosition:end];
            NSInteger contentLength = textView.text.length - selectLength;
            if (contentLength > self.maxLenth) {
                textView.text = [textView.text substringToIndex:self.maxLenth];
                self.text = textView.text;
            } else {
                self.tipLabel.text = tipStr;
            }
        } else {
            if (textView.text.length > self.maxLenth) {
                textView.text = [textView.text substringToIndex:self.maxLenth];
                self.text = textView.text;
            } else {
                self.tipLabel.text = tipStr;
            }
        }
    }
}

- (UIToolbar *)addToolbar
{
    UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 35)];
    toolbar.tintColor = [UIColor blueColor];
    toolbar.backgroundColor = [UIColor colorWithWhite:0.8 alpha:0.9];
    UIBarButtonItem *nextButton = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:self action:@selector(nextTextField)];
    UIBarButtonItem *prevButton = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:self action:@selector(prevTextField)];
    UIBarButtonItem *space = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *bar = [[UIBarButtonItem alloc] initWithTitle:@"完成" style:UIBarButtonItemStylePlain target:self action:@selector(textFieldDone)];
    toolbar.items = @[nextButton, prevButton, space, bar];
    return toolbar;
}

- (void)nextTextField {
    
}
- (void)prevTextField {
    
}

- (void)textFieldDone {
    [self resignFirstResponder];
   
}

- (void)resignFirstResponder {
    [super resignFirstResponder];
    [self.textView resignFirstResponder];
     self.tipLabel.hidden = YES;
}
- (void)becomeFirstResponder {
    [super becomeFirstResponder];
    [self.textView becomeFirstResponder];
}

- (NSString *)text {
    return self.textView.text;
}

- (void)setText:(NSString *)text {
    self.textView.text = text;
    self.placeholderLabel.hidden = text.length > 0;
    [self textViewDidChange:self.textView];
}



@end

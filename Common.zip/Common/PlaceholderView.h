//
//  PlaceholderView.h
//  IT资产移动助手运维端
//
//  Created by Apple on 2020/4/26.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@class PlaceholderView;
@protocol PlaceholderViewDelegate <NSObject>

-(void)textViewDidChangeFrame:(CGRect)frame placeView:(PlaceholderView *)placeView;

@end

@interface PlaceholderView : UIView
@property(nonatomic,copy)NSString *placeholder;
@property(nonatomic, strong)UIFont *font;
@property(nonatomic, strong)UIColor *placeholderColor;
@property(nonatomic, strong)UIColor *textColor;
@property(nonatomic, assign)NSTextAlignment textAlignment;
@property(nonatomic,copy)NSString *text;
@property(nonatomic,weak)UITextView *textView;
@property(nonatomic, assign)UIEdgeInsets contentEdge;
@property(nonatomic, assign)NSInteger maxLenth;

@property(nonatomic, weak)id<PlaceholderViewDelegate>delegate;

+ (instancetype)placeholderViewWithFrame:(CGRect)frame;
- (void)resignFirstResponder;
- (void)becomeFirstResponder;


@end

NS_ASSUME_NONNULL_END

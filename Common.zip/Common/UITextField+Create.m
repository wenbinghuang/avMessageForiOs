//
//  UITextField+Create.m
//  CommomTool
//
//  Created by Apple on 2020/9/11.
//  Copyright © 2020 Apple. All rights reserved.
//

#import "UITextField+Create.h"
#import "UIColor+Covert.h"

@implementation UITextField (Create)
+ (instancetype)textFieldWithFrame:(CGRect)frame backgroundColor:(UIColor*__nullable)backgroundColor secureTextEntry:(BOOL)secureTextEntry placeHoder:(NSString * __nullable)placeHolder placeHoderColor:(UIColor* __nullable)placeHolderColor font:(UIFont *__nullable)font textColor:(UIColor *__nullable)textColor text:(NSString *__nullable)text parentView:(UIView *__nullable)parentView {
    UITextField *textfield = [[UITextField alloc] initWithFrame:frame];
    if (backgroundColor) {
        textfield.backgroundColor = backgroundColor;
    }
    UIColor *placeholderColor = [UIColor colorWithR:120 G:120 B:120 alpha:1];
    if (font) {
        textfield.font = font;
    }
    
    if (placeHolder) {
        if (placeHolderColor) {
            placeholderColor = placeHolderColor;
        }
        textfield.attributedPlaceholder = [[NSAttributedString alloc] initWithString:placeHolder attributes:@{NSForegroundColorAttributeName: placeholderColor}];
        textfield.placeholder = placeHolder;
    }
    if (parentView) {
        [parentView addSubview:textfield];
    }
    textfield.secureTextEntry = secureTextEntry;
    
    return textfield;
}
@end

//
//  UIColor+Covert.m
//  CommomTool
//
//  Created by Apple on 2020/9/11.
//  Copyright © 2020 Apple. All rights reserved.
//

#import "UIColor+Covert.h"

@implementation UIColor (Covert)
+ (instancetype)colorWithHexString:(NSString *)hexString {
    return [UIColor colorWithHexString:hexString alpha:1.0];
}

+ (instancetype)colorWithHexString:(NSString *)hexString alpha:(float)alpha {
    NSString *cString = [[hexString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    if ([cString length] < 6) return [UIColor clearColor];
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    if ([cString hasPrefix:@"#"]) cString = [cString substringFromIndex:1];
    if ([cString length] != 6) return [UIColor clearColor];
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    unsigned int r, g, b;
    if (alpha >1.0 || alpha < 0) {
        alpha = 1.0;
    }
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    return [UIColor colorWithR:r G:g B:b alpha:alpha];
       
}


+ (instancetype)colorWithR:(float)R G:(float)G B:(float)B alpha:(float)alpha{
   
    return [UIColor colorWithRed:R/255.0f green:G/255.0f blue:B/255.0f alpha:alpha];
}


@end

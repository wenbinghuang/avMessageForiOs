//
//  UIView+Frame.m
//  CommomTool
//
//  Created by Apple on 2020/9/15.
//  Copyright © 2020 Apple. All rights reserved.
//

#import "UIView+Frame.h"

@implementation UIView (Frame)

#pragma mark setter
- (void)setX:(CGFloat)x {
    CGRect frame = self.frame;
    CGFloat y = CGRectGetMinY(frame);
    CGFloat width = CGRectGetWidth(frame);
    CGFloat height = CGRectGetHeight(frame);
    self.frame = CGRectMake(x, y, width, height);
}

- (void)setY:(CGFloat)y {
    CGRect frame = self.frame;
    CGFloat x = CGRectGetMinX(frame);
    CGFloat width = CGRectGetWidth(frame);
    CGFloat height = CGRectGetHeight(frame);
    self.frame = CGRectMake(x, y, width, height);
}

- (void)setWidth:(CGFloat)width {
    CGRect frame = self.frame;
    CGFloat x = CGRectGetMinX(frame);
    CGFloat y = CGRectGetMinY(frame);
    CGFloat height = CGRectGetHeight(frame);
    self.frame = CGRectMake(x, y, width, height);
}

- (void)setHeight:(CGFloat)height {
    CGRect frame = self.frame;
    CGFloat x = CGRectGetMinX(frame);
    CGFloat y = CGRectGetMinY(frame);
    CGFloat width = CGRectGetHeight(frame);
    self.frame = CGRectMake(x, y, width, height);
}

- (void)setCenter_x:(CGFloat)center_x {
    CGPoint center = self.center;
    self.center = CGPointMake(center_x, center.y);
}

- (void)setCenter_y:(CGFloat)center_y {
    CGPoint center = self.center;
    self.center = CGPointMake(center.x, center_y);
}


- (void)setRadius:(CGFloat)radius {
    self.layer.cornerRadius = radius;
}

- (void)setBorderColor:(UIColor *)borderColor {
    self.layer.borderColor = borderColor.CGColor;
}

- (void)setBorderWidth:(CGFloat)borderWidth {
    self.layer.borderWidth = borderWidth;
}


#pragma getter


- (CGFloat)center_y {
    return self.center.y;
}

- (CGFloat)center_x {
    return self.center.x;
}

-(CGFloat)height {
    return CGRectGetHeight(self.frame);
}

- (CGFloat)width {
    return CGRectGetWidth(self.frame);
}

- (CGFloat)y{
    return CGRectGetMinY(self.frame);
}

- (CGFloat)x {
    return CGRectGetMinX(self.frame);
}


- (CGFloat)left {
    return self.x;
}

- (CGFloat)right {
    return self.x + self.width;
}

- (CGFloat)top {
    return self.y;
}

- (CGFloat)bottom {
    return self.y + self.height;
}

- (CGFloat)borderWidth {
    return self.layer.borderWidth;
}

- (CGFloat)radius {
    return self.layer.cornerRadius;
}

- (UIColor*)borderColor {
    UIColor *borderColor = [UIColor colorWithCGColor:self.layer.borderColor];
    return borderColor;
    
}




@end

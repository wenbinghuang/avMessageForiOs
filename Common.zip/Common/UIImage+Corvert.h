//
//  UIImage+Corvert.h
//  CommomTool
//
//  Created by Apple on 2020/9/11.
//  Copyright © 2020 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (Corvert)
/**根据view生成一张图片*/
+ (instancetype)imageFromView:(UIView*)view;

+ (instancetype)imageFromColor:(UIColor *)color rect:(CGRect)rect;
@end

NS_ASSUME_NONNULL_END

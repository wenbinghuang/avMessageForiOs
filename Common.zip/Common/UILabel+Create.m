//
//  UILabel+Create.m
//  CommomTool
//
//  Created by Apple on 2020/9/11.
//  Copyright © 2020 Apple. All rights reserved.
//

#import "UILabel+Create.h"

@implementation UILabel (Create)
+ (instancetype)labelWithFrame:(CGRect)frame numberOfLines:(int)numberOfLines font:(UIFont* __nullable)font textColor:(UIColor* __nullable)textColor text:(NSString *__nullable)text backgroundColor:(UIColor *)backgroundColor parentView:(UIView *__nullable)parentView textAlignment:(NSTextAlignment)textAlignment{
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    label.textAlignment = textAlignment;
    if (parentView) {
        [parentView addSubview:label];
    }
    label.numberOfLines = numberOfLines;
    if (textColor) {
        label.textColor = textColor;
    }
    if (backgroundColor) {
        label.backgroundColor = backgroundColor;
    }
    if (font) {
        label.font = font;
    }
    if (text) {
        label.text = text;
    }
    return label;
}
@end

//
//  UITextField+Create.h
//  CommomTool
//
//  Created by Apple on 2020/9/11.
//  Copyright © 2020 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITextField (Create)
+ (instancetype)textFieldWithFrame:(CGRect)frame backgroundColor:(UIColor*__nullable)backgroundColor secureTextEntry:(BOOL)secureTextEntry placeHoder:(NSString * __nullable)placeHolder placeHoderColor:(UIColor* __nullable)placeHolderColor font:(UIFont *__nullable)font textColor:(UIColor *__nullable)textColor text:(NSString *__nullable)text parentView:(UIView *__nullable)parentView;
@end

NS_ASSUME_NONNULL_END

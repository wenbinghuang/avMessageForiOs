//
//  NSString+CacuLateBounds.m
//  CommomTool
//
//  Created by Apple on 2020/9/11.
//  Copyright © 2020 Apple. All rights reserved.
//

#import "NSString+CacuLateBounds.h"

@implementation NSString (CacuLateBounds)
- (CGSize)caculateWithMaxWidth:(CGFloat)maxWidth font:(UIFont *)font {
    if (!font) {
        font = [UIFont systemFontOfSize:[UIFont labelFontSize]];
    }
    CGSize fixSize = CGSizeZero;
    if ([self isKindOfClass:[NSString class]] && self.length > 0) {
     fixSize = [self boundingRectWithSize:CGSizeMake(maxWidth, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingTruncatesLastVisibleLine attributes:@{NSFontAttributeName: font} context:nil].size;
    }
    return fixSize;
}

- (BOOL)isEmptyStr {
    //不是string类
    if (![self isKindOfClass:[NSString class]]) {
        return YES;
    }
    
    //""
    if(self.length == 0) {
        return YES;
    }
    
    //"   abc   "
    if ([self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].length == 0) {
        return YES;
    }
    
    return NO;
}


- (instancetype)getNotEmptyStr {
    if ([self isEmptyStr]) {
        return @"";
    }
    return self;
}
@end

//
//  NSString+CacuLateBounds.h
//  CommomTool
//
//  Created by Apple on 2020/9/11.
//  Copyright © 2020 Apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (CacuLateBounds)
/**计算文字字符串的宽高，font必传*/
- (CGSize)caculateWithMaxWidth:(CGFloat)maxWidth font:(UIFont*)font;

- (instancetype)getNotEmptyStr;

- (BOOL)isEmptyStr;
@end

NS_ASSUME_NONNULL_END

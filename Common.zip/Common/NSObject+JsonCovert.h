//
//  NSObject+JsonCovert.h
//  CommomTool
//
//  Created by Apple on 2020/9/15.
//  Copyright © 2020 Apple. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (JsonCovert)
/**数组转Json字符串*/
+ (NSString *)arrayToJsonStrWithArray:(NSArray *)array;

/**字典转Json字符串*/
+ (NSString *)dictionaryToJsonStrWithDict:(NSDictionary *)dict;

/**Json字符串转数组*/
+ (NSArray *)jsonToArrayWithJsonStr:(NSString *)jsonStr;

/**Json字符串转字典*/
+ (NSDictionary *)jsonToDictionayWithJsonStr:(NSString *)jsonStr;
@end

NS_ASSUME_NONNULL_END

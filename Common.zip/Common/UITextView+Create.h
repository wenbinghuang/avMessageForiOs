//
//  UITextView+Create.h
//  CommomTool
//
//  Created by Apple on 2020/9/11.
//  Copyright © 2020 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITextView (Create)
+ (instancetype)textViewWithFrame:(CGRect)frame font:(UIFont *__nullable)font textColor:(UIColor*__nullable)textColor text:(NSString *__nullable)text backgroundColor:(UIColor * __nullable)backgroundColor parentView:(UIView *__nullable)parentView;
@end

NS_ASSUME_NONNULL_END

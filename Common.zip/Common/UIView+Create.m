//
//  UIView+Create.m
//  CommomTool
//
//  Created by Apple on 2020/9/11.
//  Copyright © 2020 Apple. All rights reserved.
//

#import "UIView+Create.h"

@implementation UIView (Create)
+ (instancetype)viewWithFrame:(CGRect)frame backgroundColor:(UIColor *__nullable)backgroundColor shouldRadius:(BOOL)shouldRadius radius:(CGFloat)radius shouldShadowOffset:(BOOL)shouldShadowOffset shadowOffset:(CGSize)shadowOffset shadowColor:(UIColor * __nullable)shadowCorlor shadowOpacity:(CGFloat)shadowOpacity shouldBorderWidth:(BOOL)shouldBorderWidth
borderWidth:(CGFloat)borderWidth borderColor:(UIColor * __nullable)borderColor  parentView:(UIView * __nullable )parentView {
    UIView *view = [[UIView alloc] initWithFrame:frame];
    if (backgroundColor) {
        view.backgroundColor = backgroundColor;
    }
    if (shouldRadius) {
        view.layer.cornerRadius = radius;
    }
    if (shouldShadowOffset) {
        [view viewShadowPathWithColor:shadowCorlor shadowOpacity:0.9 shadowRadius:1 shadowPathType:ShadowPathCommon shadowPathWidth:5];
    }
    
    if (shouldBorderWidth) {
        if (borderColor) {
            view.layer.borderColor = borderColor.CGColor;
        }
        view.layer.borderWidth = borderWidth;
    }
    
    if (parentView) {
        [parentView addSubview:view];
    }
    return view;
}

- (void)viewShadowPathWithColor:(UIColor *)shadowColor shadowOpacity:(CGFloat)shadowOpacity shadowRadius:(CGFloat)shadowRadius shadowPathType:(ShadowPathType)shadowPathType shadowPathWidth:(CGFloat)shadowPathWidth{
    
    self.layer.masksToBounds = NO;//必须要等于NO否则会把阴影切割隐藏掉
    self.layer.shadowColor = shadowColor.CGColor;// 阴影颜色
    self.layer.shadowOpacity = shadowOpacity;// 阴影透明度，默认0
    self.layer.shadowOffset = CGSizeZero;//shadowOffset阴影偏移，默认(0, -3),这个跟shadowRadius配合使用
    self.layer.shadowRadius = shadowRadius;//阴影半径，默认3
    CGRect shadowRect = CGRectZero;
    CGFloat originX,originY,sizeWith,sizeHeight;
    originX = 0;
    originY = 0;
    sizeWith = self.bounds.size.width;
    sizeHeight = self.bounds.size.height;
    
    if (shadowPathType == ShadowPathTop) {
        shadowRect = CGRectMake(originX, originY-shadowPathWidth/2, sizeWith, shadowPathWidth);
    }else if (shadowPathType == ShadowPathBottom){
        shadowRect = CGRectMake(originY, sizeHeight-shadowPathWidth/2, sizeWith, shadowPathWidth);
    }else if (shadowPathType == ShadowPathLeft){
        shadowRect = CGRectMake(originX-shadowPathWidth/2, originY, shadowPathWidth, sizeHeight);
    }else if (shadowPathType == ShadowPathRight){
        shadowRect = CGRectMake(sizeWith-shadowPathWidth/2, originY, shadowPathWidth, sizeHeight);
    }else if (shadowPathType == ShadowPathCommon){
        shadowRect = CGRectMake(originX+shadowPathWidth/2, 1, sizeWith+shadowPathWidth/2, sizeHeight+shadowPathWidth/2);
    }else if (shadowPathType == ShadowPathAround){
        shadowRect = CGRectMake(originX-shadowPathWidth/2, originY-shadowPathWidth/2, sizeWith+shadowPathWidth/2, sizeHeight+shadowPathWidth);
    }
    UIBezierPath *bezierPath = [UIBezierPath bezierPathWithRect:shadowRect];
    self.layer.shadowPath = bezierPath.CGPath;//阴影路径
}
@end

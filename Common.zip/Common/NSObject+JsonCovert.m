//
//  NSObject+JsonCovert.m
//  CommomTool
//
//  Created by Apple on 2020/9/15.
//  Copyright © 2020 Apple. All rights reserved.
//
#import "NSString+CacuLateBounds.h"
#import "NSObject+JsonCovert.h"

@implementation NSObject (JsonCovert)
/**数组转Json字符串*/
+ (NSString *)arrayToJsonStrWithArray:(NSArray *)array {
    assert([array isKindOfClass:[NSArray class]]);
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:array options:NSJSONWritingPrettyPrinted | NSJSONWritingFragmentsAllowed | NSJSONWritingWithoutEscapingSlashes error:nil];
    NSString *jsonStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    jsonStr = [jsonStr getNotEmptyStr];
    return jsonStr;
    
}

/**字典转Json字符串*/
+ (NSString *)dictionaryToJsonStrWithDict:(NSDictionary *)dict {
   assert([dict isKindOfClass:[NSDictionary class]]);
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted | NSJSONWritingFragmentsAllowed | NSJSONWritingWithoutEscapingSlashes error:nil];
       NSString *jsonStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
       jsonStr = [jsonStr getNotEmptyStr];
    return jsonStr;
}

/**Json字符串转数组*/
+ (NSArray *)jsonToArrayWithJsonStr:(NSString *)jsonStr {
    assert([jsonStr isKindOfClass:[NSString class]]);
    NSData *jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
    NSArray *array = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers | NSJSONReadingMutableLeaves | NSJSONReadingFragmentsAllowed error:nil];
    assert([array isKindOfClass:[NSArray class]]);
    return array;
}

/**Json字符串转字典*/
+ (NSDictionary *)jsonToDictionayWithJsonStr:(NSString *)jsonStr {
    assert([jsonStr isKindOfClass:[NSString class]]);
    NSData *jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers | NSJSONReadingMutableLeaves | NSJSONReadingFragmentsAllowed error:nil];
    assert([dict isKindOfClass:[NSDictionary class]]);
    return dict;
}


@end
